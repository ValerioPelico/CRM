﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaModeloCRM.Procesos
{
    public class clsCotizacion
    {
        //Datos de Tabla
        private int idCotizacion;
        private int idCliente;
        private DateTime FechaCotizacion;
        private double totalCotizacion;


        public int IdCotizacion { get => idCotizacion; set => idCotizacion = value; }
        public int IdCliente { get => idCliente; set => idCliente = value; }
        public DateTime FechaCotizacion1 { get => FechaCotizacion; set => FechaCotizacion = value; }
        public double TotalCotizacion { get => totalCotizacion; set => totalCotizacion = value; }

    }
}
