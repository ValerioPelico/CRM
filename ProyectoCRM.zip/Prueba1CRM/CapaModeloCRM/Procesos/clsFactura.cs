﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaModeloCRM.Procesos
{
    public class clsFactura
    {
        //Datos de Tabla
        private int idFactura;
        private int idEmpleado;
        private int idCliente;
        private int idTipoVenta;
        private DateTime FechaFactura;
        private double totalVenta;
        

        public int IdFactura { get => idFactura; set => idFactura = value; }
        public int IdEmpleado { get => idEmpleado; set => idEmpleado = value; }
        public int IdCliente { get => idCliente; set => idCliente = value; }
        public int IdTipoVenta { get => idTipoVenta; set => idTipoVenta = value; }
        public DateTime FechaFactura1 { get => FechaFactura; set => FechaFactura = value; }
        public double TotalVenta { get => totalVenta; set => totalVenta = value; }
    
    }
}
