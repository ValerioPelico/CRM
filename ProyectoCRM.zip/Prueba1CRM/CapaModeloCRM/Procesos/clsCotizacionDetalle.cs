﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaModeloCRM.Procesos
{
    public class clsCotizacionDetalle
    {
        //Datos de la Tabla
        private int idCotizacion;
        private int codLinea;
        private int idProducto;
        private int Cantidad;
        private double precioProducto;
        private double subTotal;
        private double descuento;
        private double subTotalDescuento;


        public int IdCotizacion { get => idCotizacion; set => idCotizacion = value; }
        public int CodLinea { get => codLinea; set => codLinea = value; }
        public int IdProducto { get => idProducto; set => idProducto = value; }
        public int Cantidad1 { get => Cantidad; set => Cantidad = value; }
        public double PrecioProducto { get => precioProducto; set => precioProducto = value; }
        public double SubTotal { get => subTotal; set => subTotal = value; }
        public double Descuento { get => descuento; set => descuento = value; }
        public double SubTotalDescuento { get => subTotalDescuento; set => subTotalDescuento = value; }
    }
}
