﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Odbc;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CapaModeloCRM;

namespace CapaControladorCRM
{
    public class clsControladorControlEmpleados
    {
        clsModeloControlEmpleados sn = new clsModeloControlEmpleados();
        int total;
        String ape = "";

        //*************************** metodos para el llenado del combobox de empleado ********************************************
        public string[] items(string tabla, string campo1, string campo2)
        {
            string[] Items = sn.llenarCmb(tabla, campo1, campo2);

            return Items;


        }

        public DataTable enviar(string tabla, string campo1, string campo2)
        {



            var dt1 = sn.obtener(tabla, campo1, campo2);

            return dt1;
        }

        //********************************** metodo para consultar el id de la venta ingresada ********************************
        public int ControlId(int id)
        {
            clsModeloControlEmpleados cs = new clsModeloControlEmpleados();
            //cs.ventas(id);

            total = cs.ventas(id);

            return total;
        }

        //********************************** metodo para la consulta del empleado ingresado *******************************
        public string ControlIdEmp(string id)
        {
            clsModeloControlEmpleados cs = new clsModeloControlEmpleados();
            //cs.ventas(id);

            ape = cs.empleado(id);

            return ape;
        }

        //******************************** Metodo para insertar las comisiones ************************************
        public void comisiones(string horas, string comisiones, int venta, int empleado)
        {
            clsModeloControlEmpleados ce = new clsModeloControlEmpleados();
            ce.insertarComisiones(horas, comisiones, venta, empleado);
        }

    }
}
