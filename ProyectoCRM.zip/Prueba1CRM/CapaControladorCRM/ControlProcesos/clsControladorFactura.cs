﻿using CapaModeloCRM;
using CapaModeloCRM.Procesos;
using System;
using System.Data;
using System.Data.Odbc;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaControladorCRM.ControlProcesos
{
    public class clsControladorFactura
    {
        private clsConexion conexion = new clsConexion(); // instanciar la clase conexion 
        private DataTable tabla; // variable tipo DataTable 
        private OdbcDataAdapter datos; // Variable OdbcDataAdapter

        //Insertar datos de encabezado factura
        public void InsertarFactura(clsFactura facturaEncabezado)
        {
            OdbcConnection con = conexion.conexion();

            OdbcCommand comando = con.CreateCommand();
            OdbcTransaction transaccion;

            transaccion = con.BeginTransaction();

            comando.Connection = con;
            comando.Transaction = transaccion;
            try
            {
                //Inserta en encabezado de factura
                comando.CommandText = "INSERT INTO facturas(pk_id_factura, fk_id_empleado, fk_id_cliente, fk_id_tipo_venta,  fecha_factura, total_factura) VALUES (?,?,?,?,?,?);";
                comando.Parameters.Add("pk_id_factura", OdbcType.Int).Value = facturaEncabezado.IdFactura;
                comando.Parameters.Add("fk_id_empleado", OdbcType.Int).Value = facturaEncabezado.IdEmpleado;
                comando.Parameters.Add("fk_id_cliente", OdbcType.Int).Value = facturaEncabezado.IdCliente;
                comando.Parameters.Add("fk_id_tipo_venta", OdbcType.Int).Value = facturaEncabezado.IdTipoVenta;
                comando.Parameters.Add("fecha_factura", OdbcType.DateTime).Value = facturaEncabezado.FechaFactura1;
                comando.Parameters.Add("total_factura", OdbcType.Double).Value = facturaEncabezado.TotalVenta;
                comando.ExecuteNonQuery();

                transaccion.Commit();
                Console.WriteLine("Transaccion Exitosa");
            }
            catch (Exception ex)
            {
                transaccion.Rollback();
                Console.WriteLine(ex.Message);
                Console.WriteLine("Trasaccion Fallida");
                MessageBox.Show("Error transaccion compras encabezado", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        //Generar id automaticos
        public int generarID(string sTabla, string sCampo)
        {
            OdbcConnection con = conexion.conexion();
            OdbcCommand comando = con.CreateCommand();
            int iIdNuevo;
            try
            {
                comando.CommandText = "SELECT max(" + sCampo + ") from " + sTabla + ";";
                int.TryParse(comando.ExecuteScalar().ToString(), out iIdNuevo);
                return (iIdNuevo + 1);
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                MessageBox.Show("Error al Generar el Id Nuevo", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 0;
            }
        }

        //Insertar a tabla detalle de Facturas
        public void InsertarDetalleFactura(clsFacturaDetalle facturaDetalle)
        {
            OdbcConnection con = conexion.conexion();

            OdbcCommand comando = con.CreateCommand();
            OdbcTransaction transaccion;

            transaccion = con.BeginTransaction();

            comando.Connection = con;
            comando.Transaction = transaccion;
            try
            {
                //Inserta en detalle de compra
                comando.CommandText = "INSERT INTO detalle_factura(fk_id_factura, cod_linea, fk_id_producto, cantidad, descuento, subtotal, sub_total_descuento) VALUES (?,?,?,?,?,?,?);";
                comando.Parameters.Add("fk_id_factura", OdbcType.Int).Value = facturaDetalle.IdFactura;
                comando.Parameters.Add("cod_linea", OdbcType.Int).Value = facturaDetalle.CodLinea;
                comando.Parameters.Add("fk_id_producto", OdbcType.Int).Value = facturaDetalle.IdProducto;
                comando.Parameters.Add("cantidad", OdbcType.Double).Value = facturaDetalle.Cantidad1;
                comando.Parameters.Add("descuento", OdbcType.Double).Value = facturaDetalle.Descuento;
                comando.Parameters.Add("subtotal", OdbcType.Double).Value = facturaDetalle.SubTotal;
                comando.Parameters.Add("sub_total_descuento", OdbcType.Double).Value = facturaDetalle.SubTotalDescuento;
                comando.ExecuteNonQuery();

                transaccion.Commit();
                Console.WriteLine("Transaccion Exitosa");
            }
            catch (Exception ex)
            {
                transaccion.Rollback();
                Console.WriteLine(ex.Message);
                Console.WriteLine("Trasaccion Fallida");
                MessageBox.Show("Error transaccion facturas detalle", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //Obtener datos para visualizacion
        public DataTable obtenerDatos(string Campo1, string Campo2, string Tabla)
        {
            try
            {
                string sComando = "select " + Campo1 + " , " + Campo2 + " from " + Tabla + ";";
                datos = new OdbcDataAdapter(sComando, conexion.conexion());
                tabla = new DataTable();
                datos.Fill(tabla);
                return tabla;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener datos");
                Console.WriteLine(ex.Message);
                return null;
            }
        }

    }
}
