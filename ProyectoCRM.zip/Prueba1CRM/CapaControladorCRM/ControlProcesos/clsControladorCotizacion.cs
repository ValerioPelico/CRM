﻿using CapaModeloCRM;
using CapaModeloCRM.Procesos;
using System;
using System.Data;
using System.Data.Odbc;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaControladorCRM.ControlProcesos
{
    public class clsControladorCotizacion
    {
        private clsConexion conexion = new clsConexion(); // instanciar la clase conexion 
        private DataTable tabla; // variable tipo DataTable 
        private OdbcDataAdapter datos; // Variable OdbcDataAdapter

        //Insertar datos del encabezado de Cotizacion
        public void InsertarCotizacion(clsCotizacion cotizacionEncabezado)
        {
            OdbcConnection con = conexion.conexion();

            OdbcCommand comando = con.CreateCommand();
            OdbcTransaction transaccion;

            transaccion = con.BeginTransaction();

            comando.Connection = con;
            comando.Transaction = transaccion;
            try
            {
                //Inserta en Cotizacion
                comando.CommandText = "INSERT INTO cotizacion(pk_id_cotizacion, fk_id_cliente, fecha_cotizacion, total_cotizacion) VALUES (?,?,?,?);";
                comando.Parameters.Add("pk_id_cotizacion", OdbcType.Int).Value = cotizacionEncabezado.IdCotizacion;
                comando.Parameters.Add("fk_id_cliente", OdbcType.Int).Value = cotizacionEncabezado.IdCliente;
                comando.Parameters.Add("fecha_cotizacion", OdbcType.DateTime).Value = cotizacionEncabezado.FechaCotizacion1;
                comando.Parameters.Add("total_cotizacion", OdbcType.Double).Value = cotizacionEncabezado.TotalCotizacion;
                comando.ExecuteNonQuery();

                transaccion.Commit();
                Console.WriteLine("Transaccion Exitosa");
            }
            catch (Exception ex)
            {
                transaccion.Rollback();
                Console.WriteLine(ex.Message);
                Console.WriteLine("Trasaccion Fallida");
                MessageBox.Show("Error transaccion pedido encabezado", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        //Generar id automaticos
        public int generarID(string sTabla, string sCampo)
        {
            OdbcConnection con = conexion.conexion();
            OdbcCommand comando = con.CreateCommand();
            int iIdNuevo;
            try
            {
                comando.CommandText = "SELECT max(" + sCampo + ") from " + sTabla + ";";
                int.TryParse(comando.ExecuteScalar().ToString(), out iIdNuevo);
                return (iIdNuevo + 1);
            }
            catch (Exception ex)
            {

                Console.WriteLine(ex.Message);
                MessageBox.Show("Error al Generar el Id Nuevo", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return 0;
            }
        }

        //Insertar a tabla de detalle cotizacion
        public void InsertarDetalleCotizacion(clsCotizacionDetalle cotizacionDetalle)
        {
            OdbcConnection con = conexion.conexion();

            OdbcCommand comando = con.CreateCommand();
            OdbcTransaction transaccion;

            transaccion = con.BeginTransaction();

            comando.Connection = con;
            comando.Transaction = transaccion;
            try
            {
                //Inserta en detalle de compra
                comando.CommandText = "INSERT INTO detalle_cotizacion(fk_id_cotizacion, cod_linea, fk_id_producto, cantidad_producto, precio_producto, subtotal_producto, descuento_producto, subtotal_descuento) VALUES (?,?,?,?,?,?,?,?);";
                comando.Parameters.Add("fk_id_pedido_encabezado", OdbcType.Int).Value = cotizacionDetalle.IdCotizacion;
                comando.Parameters.Add("cod_linea_pedido_detalle", OdbcType.Int).Value = cotizacionDetalle.CodLinea;
                comando.Parameters.Add("fk_id_producto", OdbcType.Int).Value = cotizacionDetalle.IdProducto;
                comando.Parameters.Add("cantidad_producto", OdbcType.Double).Value = cotizacionDetalle.Cantidad1;
                comando.Parameters.Add("precio_producto", OdbcType.Double).Value = cotizacionDetalle.PrecioProducto;
                comando.Parameters.Add("subtotal_producto", OdbcType.Double).Value = cotizacionDetalle.SubTotal;
                comando.Parameters.Add("descuento_producto", OdbcType.Double).Value = cotizacionDetalle.Descuento;
                comando.Parameters.Add("subtotal_descuento", OdbcType.Double).Value = cotizacionDetalle.SubTotalDescuento;
                comando.ExecuteNonQuery();

                transaccion.Commit();
                Console.WriteLine("Transaccion Exitosa");
            }
            catch (Exception ex)
            {
                transaccion.Rollback();
                Console.WriteLine(ex.Message);
                Console.WriteLine("Trasaccion Fallida");
                MessageBox.Show("Error transaccion cotizacion detalle", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //Obtener datos para visualizacion
        public DataTable obtenerDatos(string Campo1, string Campo2, string Tabla)
        {
            try
            {
                string sComando = "select " + Campo1 + " , " + Campo2 + " from " + Tabla + ";";
                datos = new OdbcDataAdapter(sComando, conexion.conexion());
                tabla = new DataTable();
                datos.Fill(tabla);
                return tabla;

            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al obtener datos");
                Console.WriteLine(ex.Message);
                return null;
            }
        }

    }
}
