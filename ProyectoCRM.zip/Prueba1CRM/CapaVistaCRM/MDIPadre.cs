﻿using CapaVistaCRM.Formularios;
using CapaVistaSeguridad;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaVistaCRM
{
    public partial class MDIPadre : Form
    {
        public MDIPadre()
        {
            InitializeComponent();
        }

        private void MDIPadre_Load(object sender, EventArgs e)
        {
            frmLogin login = new frmLogin();
            login.ShowDialog();
            textBox1.Text = login.usuario();
            timer1.Enabled = true;
            this.Location = Screen.PrimaryScreen.WorkingArea.Location;
            this.Size = Screen.PrimaryScreen.WorkingArea.Size;
        }

        private void mantenimientosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            /*clsVistaBitacora bit = new clsVistaBitacora();
            clsFuncionesSeguridad seguridad = new clsFuncionesSeguridad();
            //el numero 1 se debe cambiar por el numero de la aplicacion que se tiene asignado en la base de datos 
            if (seguridad.PermisosAcceso("1", textBox1.Text) == 1)
            {
                bit.user(textBox1.Text);
                // SE DEBE CAMBIAR BANCO POR EL FORMULARIO QUE SE DESEA ABRIR
                frmCliente variable = new frmCliente(textBox1.Text, this);
                variable.MdiParent = this;
                variable.Show();
            }
            else
            {
                MessageBox.Show("El Usuario No Cuenta Con Permisos De Acceso A La Aplicación");
            }*/
        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            clsVistaBitacora bit = new clsVistaBitacora();
            clsFuncionesSeguridad seguridad = new clsFuncionesSeguridad();
            //el numero 1 se debe cambiar por el numero de la aplicacion que se tiene asignado en la base de datos 
            if (seguridad.PermisosAcceso("1", textBox1.Text) == 1)
            {
                bit.user(textBox1.Text);
                // SE DEBE CAMBIAR BANCO POR EL FORMULARIO QUE SE DESEA ABRIR
                frmCliente variable = new frmCliente(textBox1.Text, this);
                variable.MdiParent = this;
                variable.Show();
            }
            else
            {

            }
        }

        private void controlEmpleadosVentasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmControlEmpleados conem = new frmControlEmpleados();
            conem.MdiParent = this;
            conem.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lblHora.Text = DateTime.Now.ToLongTimeString();
            lblFecha.Text = DateTime.Now.ToLongDateString();
        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            lblHora.Text = DateTime.Now.ToLongTimeString();
            lblFecha.Text = DateTime.Now.ToLongDateString();
        }
    }
}
