﻿using CapaControladorCRM;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Odbc;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaVistaCRM.Formularios
{
    public partial class frmPedidos : Form
    {
        double subtot1, subtot2, subtotal, prec;
        double total;
        int idProducto, ContadorFilas, idprod, cant;
        String prueba = "", prueba2 = "";
        int pr = 0;

        public frmPedidos()
        {
            InitializeComponent();

            tltPrecio.SetToolTip(this.txtPrecio, "Ingrese el precio en numero entero o decimal");
            tltProducto.SetToolTip(this.cmbProducto, "Ingrese el codigo del producto a buscar");
            tltCantidad.SetToolTip(this.txtCantidad, "Ingrese la cantidad deseada de producto");
        }

        // *************************************** Verifica que solo se ingresen numeros ******************************
        private void txtCantidad_KeyPress(object sender, KeyPressEventArgs e)
        {
            SoloNumeros(e);
        }

        //**************************************** Metodo Para verificar que solo se ingresen numeros *********************
        public static void SoloNumeros(KeyPressEventArgs v)
        {
            if (Char.IsDigit(v.KeyChar))
            {
                v.Handled = false;
            }
            else if (Char.IsSeparator(v.KeyChar))
            {
                v.Handled = false;
            }
            else if (Char.IsControl(v.KeyChar))
            {
                v.Handled = false;
            }
            else
            {
                v.Handled = true;
                MessageBox.Show("Solo Numeros");
            }
        }

        clsControladorPedido cn = new clsControladorPedido();

        //*********************************************** Metodo Para hacer el llenado del combobox de producto **********************
        public void llenarse(string tabla, string campo1, string campo2)
        {

            string tbl = tabla;
            string cmp1 = campo1;
            string cmp2 = campo2;

            /*nombre del cmb*/
            cmbProducto.ValueMember = "numero";
            /*nombre del cmb*/
            cmbProducto.DisplayMember = "nombre";

            string[] items = cn.items(tabla, campo1, campo2);

            for (int i = 0; i < items.Length; i++)
            {
                if (items[i] != null)
                {
                    if (items[i] != "")
                    {
                        /*nombre del cmb*/
                        cmbProducto.Items.Add(items[i]);
                    }
                }

            }

            var dt2 = cn.enviar(tabla, campo1, campo2);
            AutoCompleteStringCollection coleccion = new AutoCompleteStringCollection();
            foreach (DataRow row in dt2.Rows)
            {

                coleccion.Add(Convert.ToString(row[campo1]) + "-" + Convert.ToString(row[campo2]));
                //coleccion.Add(Convert.ToString(row[campo2]) + "-" + Convert.ToString(row[campo1]));
            }

            /*nombre del cmb*/
            cmbProducto.AutoCompleteCustomSource = coleccion;
            /*nombre del cmb*/
            cmbProducto.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            /*nombre del cmb*/
            cmbProducto.AutoCompleteSource = AutoCompleteSource.CustomSource;
        }

        // **************************************************** Metodo para el llenado del combobox de fabrica ****************************
        public void llenarseFabrica(string tabla, string campo1, string campo2)
        {

            string tbl = tabla;
            string cmp1 = campo1;
            string cmp2 = campo2;

            /*nombre del cmb*/
            cmbFabrica.ValueMember = "numero";
            /*nombre del cmb*/
            cmbFabrica.DisplayMember = "nombre";

            string[] items = cn.itemsFabrica(tabla, campo1, campo2);

            for (int i = 0; i < items.Length; i++)
            {
                if (items[i] != null)
                {
                    if (items[i] != "")
                    {
                        /*nombre del cmb*/
                        cmbFabrica.Items.Add(items[i]);
                    }
                }

            }

            var dt2 = cn.enviarFabrica(tabla, campo1, campo2);
            AutoCompleteStringCollection coleccion = new AutoCompleteStringCollection();
            foreach (DataRow row in dt2.Rows)
            {

                coleccion.Add(Convert.ToString(row[campo1]) + "-" + Convert.ToString(row[campo2]));
                //coleccion.Add(Convert.ToString(row[campo2]) + "-" + Convert.ToString(row[campo1]));
            }

            /*nombre del cmb*/
            cmbFabrica.AutoCompleteCustomSource = coleccion;
            /*nombre del cmb*/
            cmbFabrica.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            /*nombre del cmb*/
            cmbFabrica.AutoCompleteSource = AutoCompleteSource.CustomSource;
        }

        // **************************************** Metodo para verificar que solo se ingresen numeros decimales
        public static void NumeroDecimal(KeyPressEventArgs v)
        {
            if (Char.IsDigit(v.KeyChar))
            {
                v.Handled = false;
            } else if (Char.IsSeparator(v.KeyChar))
            {
                v.Handled = false;
            } else if (Char.IsControl(v.KeyChar))
            {
                v.Handled = false;
            } else if (v.KeyChar.ToString().Equals("."))
            {
                v.Handled = false;
            } else
            {
                v.Handled = true;
                MessageBox.Show("Solo Numeros con Punto Decimal");
            }
        }

        //******************************** Verificar el ingreso al textbox y hace la actualizacion para el subtotal **********************
        private void txtPrecio_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (!(string.IsNullOrEmpty(txtCantidad.Text)) && !(string.IsNullOrEmpty(txtPrecio.Text)))
                {
                    subtot1 = Convert.ToDouble(txtCantidad.Text.ToString());
                    subtot2 = Convert.ToDouble(txtPrecio.Text.ToString());

                    subtotal = subtot1 * subtot2;
                    txtSubtotal.Text = subtotal.ToString();
                }
            }
            catch
            {
                MessageBox.Show("Formato Incompatible");
                txtPrecio.Text = "";
                return;
            }
        }

        //***************************** Realiza la insercion dentro del datagriedview de los productos seleccionados ***********************
        private void btnAgregar_Click(object sender, EventArgs e)
        {
            if((string.IsNullOrEmpty(txtCantidad.Text)) || (string.IsNullOrEmpty(txtPrecio.Text)) || (string.IsNullOrEmpty(txtSubtotal.Text)) || (string.IsNullOrEmpty(cmbProducto.Text)))
            {
                MessageBox.Show("Llene todos lo campos");
                return;
            }
            idProducto = Convert.ToInt32(cmbProducto.SelectedIndex.ToString());
            idProducto = idProducto + 1;
            this.dgvProducto.Rows.Add(idProducto, txtCantidad.Text, txtPrecio.Text, txtSubtotal.Text);
            total = 0;

            foreach (DataGridViewRow row in dgvProducto.Rows)
            {
                total += Convert.ToDouble(row.Cells["Column4"].Value);
                txtTotal.Text = total.ToString();
            }
        }

        //****************************************** Manda a traer el metodo de llenado del combobox de producto **************************
        private void cmbProducto_Click(object sender, EventArgs e)
        {
            llenarse("producto", "pk_id_producto", "nombre_producto");
        }

        //*********************************** Prueba para ver el dato seleccionado en combobox producto **********************
        private void cmbProducto_SelectedValueChanged(object sender, EventArgs e)
        {
            prueba = cmbProducto.SelectedIndex.ToString();
            label1.Text = prueba;
        }

        //********************************** Manda a traer el metodo de llenado del combobox de fabrica *******************************
        private void cmbFabrica_Click(object sender, EventArgs e)
        {
            llenarseFabrica("fabrica", "pk_id_fabrica", "descripcion_fabrica");
        }

        //********************************** verifica que solo se ingresen numeros ***********************************
        private void cmbFabrica_KeyPress(object sender, KeyPressEventArgs e)
        {
            SoloNumeros(e);
        }

        //*********************************** verifica que solo se ingresen numeros ********************************
        private void cmbProducto_KeyPress(object sender, KeyPressEventArgs e)
        {
            SoloNumeros(e);
        }

        //*************************************** Metodo que limpia los datos en el formulario *********************************
        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            limpiar();
        }

        //**************************************** Metodo para limpiar los datos en pantalla *********************************
        public void limpiar ()
        {
            txtCantidad.Text = "";
            txtPrecio.Text = "";
            txtTotal.Text = "";
            txtSubtotal.Text = "";
            cmbFabrica.SelectedIndex = -1;
            cmbProducto.SelectedIndex = -1;
            do
            {
                foreach (DataGridViewRow row in dgvProducto.Rows)
                {
                    try
                    {
                        dgvProducto.Rows.Remove(row);
                    }
                    catch (Exception) { }
                }
            } while (dgvProducto.Rows.Count > 1);
        }

        //***************************************** Metodo que inserta el pedido **********************************************
        private void btnInsertar_Click(object sender, EventArgs e)
        {
            if ((string.IsNullOrEmpty(cmbFabrica.Text)) || (string.IsNullOrEmpty(txtTotal.Text)))
            {
                MessageBox.Show("No se han completado todos los campos necesarios");
                return;
            }

            string fabri = cmbFabrica.SelectedIndex.ToString();
            string fecha = dtpFecha.Value.ToString("dd/MM/yyyy");
            clsControladorPedido cp = new clsControladorPedido();
            prueba = cp.prueba(pr).ToString();
            label3.Text = prueba;
            clsControladorPedido cc = new clsControladorPedido();
            cp.insertPedido(Convert.ToInt32(fabri), fecha, Convert.ToDouble(txtTotal.Text.ToString()));

            label4.Text = dgvProducto.Rows.Count.ToString();
            prueba2 = dgvProducto.Rows.Count.ToString();
            ContadorFilas = Convert.ToInt32(prueba2);
            ContadorFilas = ContadorFilas - 1;
            //DataGridViewRow row = dgvProducto.Rows[0];  // fila 1
            //int i = 0;

            for (int g = 0; g < ContadorFilas; g++)
            {
                DataGridViewRow row = dgvProducto.Rows[g];
                idprod = Convert.ToInt32(row.Cells[0].Value);
                cant = Convert.ToInt32(row.Cells[1].Value);
                prec = Convert.ToDouble(row.Cells[2].Value);
                subtotal = Convert.ToDouble(row.Cells[3].Value);
                Insertar(idprod, cant, prec, subtotal);
            }

            MessageBox.Show("Registro Exitoso");
            limpiar();
        }

        public void Insertar(int p, int c, double pr, double s)
        {

            clsControladorPedido cc = new clsControladorPedido();
            cc.insertdetalle(p, c, pr, s);
        }

        private void cmbFabrica_SelectedIndexChanged(object sender, EventArgs e)
        {
            prueba = cmbFabrica.SelectedIndex.ToString();
            label2.Text = prueba;
        }

        //**************************** verifica que solo se ingresen numeros decimales ***************************************
        private void txtPrecio_KeyPress(object sender, KeyPressEventArgs e)
        {
            NumeroDecimal(e);
        }

        //**************************** verifica que el dato ingresado y realiza la actualizacion en subtotal *****************************
        private void txtCantidad_TextChanged(object sender, EventArgs e)
        {
            try
            {
                if (!(string.IsNullOrEmpty(txtCantidad.Text)) && !(string.IsNullOrEmpty(txtPrecio.Text)))
                {
                    subtot1 = Convert.ToDouble(txtCantidad.Text.ToString());
                    subtot2 = Convert.ToDouble(txtPrecio.Text.ToString());

                    subtotal = subtot1 * subtot2;
                    txtSubtotal.Text = subtotal.ToString();
                }
            }
            catch
            {
                MessageBox.Show("Formato Incompatible");
                txtPrecio.Text = "";
                return;
            }
        }
    }
}
