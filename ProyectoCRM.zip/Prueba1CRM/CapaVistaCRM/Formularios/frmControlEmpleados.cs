﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CapaControladorCRM;

namespace CapaVistaCRM.Formularios
{
    public partial class frmControlEmpleados : Form
    {
        public frmControlEmpleados()
        {
            InitializeComponent();
        }

        private void frmControlEmpleados_Load(object sender, EventArgs e)
        {
            //String prueba="";
            //cmbEmpleado.SelectedValue = prueba;
            //txtCodEmp.Text = prueba;
        }

        clsControladorControlEmpleados cn = new clsControladorControlEmpleados();

        public void llenarse(string tabla, string campo1, string campo2)
        {

            string tbl = tabla;
            string cmp1 = campo1;
            string cmp2 = campo2;



            /*nombre del cmb*/
            cmbEmpleado.ValueMember = "numero";
            /*nombre del cmb*/
            cmbEmpleado.DisplayMember = "nombre";

            string[] items = cn.items(tabla, campo1, campo2);



            for (int i = 0; i < items.Length; i++)
            {
                if (items[i] != null)
                {
                    if (items[i] != "")
                    {
                        /*nombre del cmb*/
                        cmbEmpleado.Items.Add(items[i]);
                    }
                }

            }

            var dt2 = cn.enviar(tabla, campo1, campo2);
            AutoCompleteStringCollection coleccion = new AutoCompleteStringCollection();
            foreach (DataRow row in dt2.Rows)
            {

                coleccion.Add(Convert.ToString(row[campo1]) + "-" + Convert.ToString(row[campo2]));
                //coleccion.Add(Convert.ToString(row[campo2]) + "-" + Convert.ToString(row[campo1]));


            }

            /*nombre del cmb*/
            cmbEmpleado.AutoCompleteCustomSource = coleccion;
            /*nombre del cmb*/
            cmbEmpleado.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
            /*nombre del cmb*/
            cmbEmpleado.AutoCompleteSource = AutoCompleteSource.CustomSource;


        }

        private void cmbEmpleado_MouseClick(object sender, MouseEventArgs e)
        {
            //llenarse("empleado", "pk_id_empleado", "nombre1_empleado");
        }

        private void cmbEmpleado_Click(object sender, EventArgs e)
        {
            llenarse("empleado", "pk_id_empleado", "nombre1_empleado");
        }

        private void btnEmpleado_Click(object sender, EventArgs e)
        {
            /*String prueba = "";
            prueba = cmbEmpleado.SelectedText.ToString();
            txtCodEmp.Text = prueba;*/
        }

        private void cmbEmpleado_SelectedValueChanged(object sender, EventArgs e)
        {
            String prueba = "";
            prueba = cmbEmpleado.SelectedIndex.ToString();
            label1.Text = prueba;
        }
    }
}
