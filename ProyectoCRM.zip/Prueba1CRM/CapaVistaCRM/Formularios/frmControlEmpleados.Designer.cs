﻿namespace CapaVistaCRM.Formularios
{
    partial class frmControlEmpleados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbcControEmpleado = new System.Windows.Forms.TabControl();
            this.tabInsertar = new System.Windows.Forms.TabPage();
            this.txtTotalComisiones = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.lblTotalComisiones = new System.Windows.Forms.Label();
            this.btnInsertar = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.btnAgregar = new System.Windows.Forms.Button();
            this.dgvControlEmp = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cmbEmpleado = new System.Windows.Forms.ComboBox();
            this.btnEmpleado = new System.Windows.Forms.Button();
            this.txtNomEmp = new System.Windows.Forms.TextBox();
            this.lblNomEmpleado = new System.Windows.Forms.Label();
            this.lblCodEmp = new System.Windows.Forms.Label();
            this.gbxBuscarVenta = new System.Windows.Forms.GroupBox();
            this.lblTotalVenta = new System.Windows.Forms.Label();
            this.txtTotalVenta = new System.Windows.Forms.TextBox();
            this.btnBuscarVenta = new System.Windows.Forms.Button();
            this.txtCodVenta = new System.Windows.Forms.TextBox();
            this.lblCodVenta = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lblControl = new System.Windows.Forms.Label();
            this.btnAyuda = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.tbcControEmpleado.SuspendLayout();
            this.tabInsertar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvControlEmp)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.gbxBuscarVenta.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbcControEmpleado
            // 
            this.tbcControEmpleado.Controls.Add(this.tabInsertar);
            this.tbcControEmpleado.Controls.Add(this.tabPage2);
            this.tbcControEmpleado.Font = new System.Drawing.Font("Rockwell Condensed", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbcControEmpleado.Location = new System.Drawing.Point(12, 62);
            this.tbcControEmpleado.Name = "tbcControEmpleado";
            this.tbcControEmpleado.SelectedIndex = 0;
            this.tbcControEmpleado.Size = new System.Drawing.Size(1304, 547);
            this.tbcControEmpleado.TabIndex = 1;
            // 
            // tabInsertar
            // 
            this.tabInsertar.BackColor = System.Drawing.Color.Silver;
            this.tabInsertar.Controls.Add(this.txtTotalComisiones);
            this.tabInsertar.Controls.Add(this.button2);
            this.tabInsertar.Controls.Add(this.lblTotalComisiones);
            this.tabInsertar.Controls.Add(this.btnInsertar);
            this.tabInsertar.Controls.Add(this.dateTimePicker1);
            this.tabInsertar.Controls.Add(this.btnAgregar);
            this.tabInsertar.Controls.Add(this.dgvControlEmp);
            this.tabInsertar.Controls.Add(this.groupBox1);
            this.tabInsertar.Controls.Add(this.gbxBuscarVenta);
            this.tabInsertar.Location = new System.Drawing.Point(4, 29);
            this.tabInsertar.Name = "tabInsertar";
            this.tabInsertar.Padding = new System.Windows.Forms.Padding(3);
            this.tabInsertar.Size = new System.Drawing.Size(1296, 514);
            this.tabInsertar.TabIndex = 0;
            this.tabInsertar.Text = "Insertar Control Empleado";
            this.tabInsertar.ToolTipText = "Insercion de Comisiones por Empleado";
            // 
            // txtTotalComisiones
            // 
            this.txtTotalComisiones.Location = new System.Drawing.Point(231, 470);
            this.txtTotalComisiones.Name = "txtTotalComisiones";
            this.txtTotalComisiones.Size = new System.Drawing.Size(135, 27);
            this.txtTotalComisiones.TabIndex = 8;
            // 
            // button2
            // 
            this.button2.Image = global::CapaVistaCRM.Properties.Resources.logo_orange_ccleaner_clean_icon_1343651;
            this.button2.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button2.Location = new System.Drawing.Point(1191, 473);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(90, 34);
            this.button2.TabIndex = 7;
            this.button2.Text = "Limpiar";
            this.button2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button2.UseVisualStyleBackColor = true;
            // 
            // lblTotalComisiones
            // 
            this.lblTotalComisiones.AutoSize = true;
            this.lblTotalComisiones.Font = new System.Drawing.Font("Rockwell Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalComisiones.Location = new System.Drawing.Point(107, 470);
            this.lblTotalComisiones.Name = "lblTotalComisiones";
            this.lblTotalComisiones.Size = new System.Drawing.Size(118, 24);
            this.lblTotalComisiones.TabIndex = 6;
            this.lblTotalComisiones.Text = "Total Comisiones";
            // 
            // btnInsertar
            // 
            this.btnInsertar.Image = global::CapaVistaCRM.Properties.Resources.construction_project_plan_building_architect_design_develop_73_icon_icons_com_60243;
            this.btnInsertar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnInsertar.Location = new System.Drawing.Point(828, 473);
            this.btnInsertar.Name = "btnInsertar";
            this.btnInsertar.Size = new System.Drawing.Size(145, 35);
            this.btnInsertar.TabIndex = 5;
            this.btnInsertar.Text = "Insertar Comision";
            this.btnInsertar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnInsertar.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(48, 269);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(253, 27);
            this.dateTimePicker1.TabIndex = 4;
            // 
            // btnAgregar
            // 
            this.btnAgregar.Image = global::CapaVistaCRM.Properties.Resources.businesspackage_additionalpackage_box_add_insert_negoci_2335;
            this.btnAgregar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAgregar.Location = new System.Drawing.Point(875, 268);
            this.btnAgregar.Name = "btnAgregar";
            this.btnAgregar.Size = new System.Drawing.Size(125, 30);
            this.btnAgregar.TabIndex = 3;
            this.btnAgregar.Text = "Agregar Venta";
            this.btnAgregar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnAgregar.UseVisualStyleBackColor = true;
            // 
            // dgvControlEmp
            // 
            this.dgvControlEmp.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvControlEmp.Location = new System.Drawing.Point(22, 304);
            this.dgvControlEmp.Name = "dgvControlEmp";
            this.dgvControlEmp.RowHeadersWidth = 51;
            this.dgvControlEmp.RowTemplate.Height = 24;
            this.dgvControlEmp.Size = new System.Drawing.Size(1260, 150);
            this.dgvControlEmp.TabIndex = 2;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cmbEmpleado);
            this.groupBox1.Controls.Add(this.btnEmpleado);
            this.groupBox1.Controls.Add(this.txtNomEmp);
            this.groupBox1.Controls.Add(this.lblNomEmpleado);
            this.groupBox1.Controls.Add(this.lblCodEmp);
            this.groupBox1.Location = new System.Drawing.Point(22, 19);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(1250, 100);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Agregar Empleado";
            // 
            // cmbEmpleado
            // 
            this.cmbEmpleado.FormattingEnabled = true;
            this.cmbEmpleado.Location = new System.Drawing.Point(153, 43);
            this.cmbEmpleado.Name = "cmbEmpleado";
            this.cmbEmpleado.Size = new System.Drawing.Size(147, 28);
            this.cmbEmpleado.TabIndex = 5;
            this.cmbEmpleado.SelectedValueChanged += new System.EventHandler(this.cmbEmpleado_SelectedValueChanged);
            this.cmbEmpleado.Click += new System.EventHandler(this.cmbEmpleado_Click);
            this.cmbEmpleado.MouseClick += new System.Windows.Forms.MouseEventHandler(this.cmbEmpleado_MouseClick);
            // 
            // btnEmpleado
            // 
            this.btnEmpleado.Image = global::CapaVistaCRM.Properties.Resources.find_users_applications_search_2908;
            this.btnEmpleado.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEmpleado.Location = new System.Drawing.Point(318, 43);
            this.btnEmpleado.Name = "btnEmpleado";
            this.btnEmpleado.Size = new System.Drawing.Size(137, 27);
            this.btnEmpleado.TabIndex = 4;
            this.btnEmpleado.Text = "Buscar Empleado";
            this.btnEmpleado.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnEmpleado.UseVisualStyleBackColor = true;
            this.btnEmpleado.Click += new System.EventHandler(this.btnEmpleado_Click);
            // 
            // txtNomEmp
            // 
            this.txtNomEmp.Enabled = false;
            this.txtNomEmp.Location = new System.Drawing.Point(952, 42);
            this.txtNomEmp.Name = "txtNomEmp";
            this.txtNomEmp.Size = new System.Drawing.Size(139, 27);
            this.txtNomEmp.TabIndex = 3;
            // 
            // lblNomEmpleado
            // 
            this.lblNomEmpleado.AutoSize = true;
            this.lblNomEmpleado.Font = new System.Drawing.Font("Rockwell Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNomEmpleado.Location = new System.Drawing.Point(802, 42);
            this.lblNomEmpleado.Name = "lblNomEmpleado";
            this.lblNomEmpleado.Size = new System.Drawing.Size(127, 24);
            this.lblNomEmpleado.TabIndex = 2;
            this.lblNomEmpleado.Text = "Nombre Empleado";
            // 
            // lblCodEmp
            // 
            this.lblCodEmp.AutoSize = true;
            this.lblCodEmp.Font = new System.Drawing.Font("Rockwell Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodEmp.Location = new System.Drawing.Point(26, 42);
            this.lblCodEmp.Name = "lblCodEmp";
            this.lblCodEmp.Size = new System.Drawing.Size(120, 24);
            this.lblCodEmp.TabIndex = 0;
            this.lblCodEmp.Text = "Codigo Empleado";
            // 
            // gbxBuscarVenta
            // 
            this.gbxBuscarVenta.Controls.Add(this.lblTotalVenta);
            this.gbxBuscarVenta.Controls.Add(this.txtTotalVenta);
            this.gbxBuscarVenta.Controls.Add(this.btnBuscarVenta);
            this.gbxBuscarVenta.Controls.Add(this.txtCodVenta);
            this.gbxBuscarVenta.Controls.Add(this.lblCodVenta);
            this.gbxBuscarVenta.Location = new System.Drawing.Point(22, 153);
            this.gbxBuscarVenta.Name = "gbxBuscarVenta";
            this.gbxBuscarVenta.Size = new System.Drawing.Size(1250, 109);
            this.gbxBuscarVenta.TabIndex = 0;
            this.gbxBuscarVenta.TabStop = false;
            this.gbxBuscarVenta.Text = "Busqueda de Venta";
            // 
            // lblTotalVenta
            // 
            this.lblTotalVenta.AutoSize = true;
            this.lblTotalVenta.Font = new System.Drawing.Font("Rockwell Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalVenta.Location = new System.Drawing.Point(802, 48);
            this.lblTotalVenta.Name = "lblTotalVenta";
            this.lblTotalVenta.Size = new System.Drawing.Size(87, 24);
            this.lblTotalVenta.TabIndex = 4;
            this.lblTotalVenta.Text = "Total Venta";
            // 
            // txtTotalVenta
            // 
            this.txtTotalVenta.Enabled = false;
            this.txtTotalVenta.Location = new System.Drawing.Point(952, 45);
            this.txtTotalVenta.Name = "txtTotalVenta";
            this.txtTotalVenta.Size = new System.Drawing.Size(139, 27);
            this.txtTotalVenta.TabIndex = 3;
            // 
            // btnBuscarVenta
            // 
            this.btnBuscarVenta.Image = global::CapaVistaCRM.Properties.Resources.shoppingcart_77968;
            this.btnBuscarVenta.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuscarVenta.Location = new System.Drawing.Point(318, 46);
            this.btnBuscarVenta.Name = "btnBuscarVenta";
            this.btnBuscarVenta.Size = new System.Drawing.Size(124, 26);
            this.btnBuscarVenta.TabIndex = 2;
            this.btnBuscarVenta.Text = "Buscar Venta";
            this.btnBuscarVenta.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuscarVenta.UseVisualStyleBackColor = true;
            // 
            // txtCodVenta
            // 
            this.txtCodVenta.Location = new System.Drawing.Point(158, 45);
            this.txtCodVenta.Name = "txtCodVenta";
            this.txtCodVenta.Size = new System.Drawing.Size(121, 27);
            this.txtCodVenta.TabIndex = 1;
            // 
            // lblCodVenta
            // 
            this.lblCodVenta.AutoSize = true;
            this.lblCodVenta.Font = new System.Drawing.Font("Rockwell Condensed", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCodVenta.Location = new System.Drawing.Point(22, 48);
            this.lblCodVenta.Name = "lblCodVenta";
            this.lblCodVenta.Size = new System.Drawing.Size(118, 24);
            this.lblCodVenta.TabIndex = 0;
            this.lblCodVenta.Text = "Codigo de Venta";
            // 
            // tabPage2
            // 
            this.tabPage2.Location = new System.Drawing.Point(4, 29);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1296, 514);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Modificar Control Empleado";
            this.tabPage2.ToolTipText = "Modificar Comisiones por Empleado";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // lblControl
            // 
            this.lblControl.AutoSize = true;
            this.lblControl.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lblControl.Font = new System.Drawing.Font("Rockwell Condensed", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblControl.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.lblControl.Location = new System.Drawing.Point(13, 8);
            this.lblControl.Name = "lblControl";
            this.lblControl.Size = new System.Drawing.Size(212, 29);
            this.lblControl.TabIndex = 2;
            this.lblControl.Text = "Control Empleados Ventas";
            // 
            // btnAyuda
            // 
            this.btnAyuda.Image = global::CapaVistaCRM.Properties.Resources.search_locate_find_icon_icons_com_67287;
            this.btnAyuda.Location = new System.Drawing.Point(1250, 8);
            this.btnAyuda.Name = "btnAyuda";
            this.btnAyuda.Size = new System.Drawing.Size(62, 48);
            this.btnAyuda.TabIndex = 0;
            this.btnAyuda.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(433, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 17);
            this.label1.TabIndex = 3;
            this.label1.Text = "label1";
            // 
            // frmControlEmpleados
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(1328, 621);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblControl);
            this.Controls.Add(this.tbcControEmpleado);
            this.Controls.Add(this.btnAyuda);
            this.MaximizeBox = false;
            this.Name = "frmControlEmpleados";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "5001 - Control Empleados Ventas";
            this.Load += new System.EventHandler(this.frmControlEmpleados_Load);
            this.tbcControEmpleado.ResumeLayout(false);
            this.tabInsertar.ResumeLayout(false);
            this.tabInsertar.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvControlEmp)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.gbxBuscarVenta.ResumeLayout(false);
            this.gbxBuscarVenta.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAyuda;
        private System.Windows.Forms.TabControl tbcControEmpleado;
        private System.Windows.Forms.TabPage tabInsertar;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Label lblControl;
        private System.Windows.Forms.GroupBox gbxBuscarVenta;
        private System.Windows.Forms.Button btnBuscarVenta;
        private System.Windows.Forms.TextBox txtCodVenta;
        private System.Windows.Forms.Label lblCodVenta;
        private System.Windows.Forms.Button btnAgregar;
        private System.Windows.Forms.DataGridView dgvControlEmp;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnEmpleado;
        private System.Windows.Forms.TextBox txtNomEmp;
        private System.Windows.Forms.Label lblNomEmpleado;
        private System.Windows.Forms.Label lblCodEmp;
        private System.Windows.Forms.Label lblTotalVenta;
        private System.Windows.Forms.TextBox txtTotalVenta;
        private System.Windows.Forms.TextBox txtTotalComisiones;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label lblTotalComisiones;
        private System.Windows.Forms.Button btnInsertar;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ComboBox cmbEmpleado;
        private System.Windows.Forms.Label label1;
    }
}