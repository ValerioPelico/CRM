﻿using CapaControladorCRM;
using CapaControladorCRM.ControlProcesos;
using CapaModeloCRM;
using CapaModeloCRM.Procesos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Odbc;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaVistaCRM.Formularios
{
    public partial class frmFactura : Form
    {
        clsConexion cn = new clsConexion();
        //Variables Globales
        private clsControladorFactura controladorFactura = new clsControladorFactura();
        private clsFactura facturaEncabezado;
        private clsFacturaDetalle facturaDetalle;
        private clsConexion conexion = new clsConexion();
        private int IDProducto, Cantidad, estadoProceso;
        private double Precio, SubTotal, TotalValor;

        public frmFactura()
        {
            InitializeComponent();
            BloquearComponentes();
            cargarClientes();
            cargarProductos();
            cargarEmpleados();
            cargarTipoVenta();
            tltCliente.SetToolTip(this.cbxCliente, "Ingrese el Codigo del Cliente");
            tltEmpleado.SetToolTip(this.cbxEmpleado, "Ingrese numero de empleado a buscar");
            tltTipoVenta.SetToolTip(this.cbxTipoVenta, "Ingrese 1 para el credito y 2 para el contado.");
        }

        //Bloquea componentes
        private void BloquearComponentes()
        {
            //dgvCotizacion.Enabled = false;
            dtpFecha.Enabled = false;

            txtApellidos.Enabled = false;
            txtDireccion.Enabled = false;
            txtNIT.Enabled = false;
            //txtNoFactura.Enabled = false;
            txtNombreCliente.Enabled = false;
            txtTotal.Enabled = false;
        }

        //Carga datos a combobx clientes
        private void cargarClientes()
        {
            try
            {
                string sSQL = "SELECT pk_id_cliente FROM clientes";
                OdbcCommand comando = new OdbcCommand(sSQL, cn.conexion());
                OdbcDataReader registro = comando.ExecuteReader();

                cbxCliente.DropDownStyle = ComboBoxStyle.DropDownList;
                while (registro.Read())
                {
                    cbxCliente.Items.Add(registro["pk_id_cliente"].ToString());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                MessageBox.Show("Error al cargar datos combobox", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        //Carga datos a combobx empleados
        private void cargarEmpleados()
        {
            try
            {
                string sSQL = "SELECT pk_id_empleado FROM empleado";
                OdbcCommand comando = new OdbcCommand(sSQL, cn.conexion());
                OdbcDataReader registro = comando.ExecuteReader();

                cbxEmpleado.DropDownStyle = ComboBoxStyle.DropDownList;
                while (registro.Read())
                {
                    cbxEmpleado.Items.Add(registro["pk_id_empleado"].ToString());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                MessageBox.Show("Error al cargar datos combobox", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }


        //Carga datos a combobx tipo venta
        private void cargarTipoVenta()
        {
            try
            {
                string sSQL = "SELECT pk_id_tipo_venta FROM tipo_venta";
                OdbcCommand comando = new OdbcCommand(sSQL, cn.conexion());
                OdbcDataReader registro = comando.ExecuteReader();

                cbxTipoVenta.DropDownStyle = ComboBoxStyle.DropDownList;
                while (registro.Read())
                {
                    cbxTipoVenta.Items.Add(registro["pk_id_tipo_venta"].ToString());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                MessageBox.Show("Error al cargar datos combobox", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void cargarProductos()
        {
            cbxProducto.ValueMember = "pk_id_producto";
            cbxProducto.DisplayMember = "nombre_producto";
            cbxProducto.DataSource = controladorFactura.obtenerDatos("pk_id_producto", "nombre_producto", "producto");
        }


        private void cbxCliente_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Toma datos y los muestra en textbox, de acuerdo al id seleccionado
            try
            {

                if (cbxCliente.SelectedIndex >= 0)
                {
                    string sSQL = "SELECT nombre_cliente, apellido_cliente, nit_cliente, direccion_cliente FROM clientes WHERE pk_id_cliente=" + int.Parse(cbxCliente.SelectedItem.ToString());
                    OdbcCommand comando = new OdbcCommand(sSQL, cn.conexion());
                    OdbcDataReader registro = comando.ExecuteReader();

                    while (registro.Read())
                    {
                        txtNombreCliente.Text = registro["nombre_cliente"].ToString();
                        txtApellidos.Text = registro["apellido_cliente"].ToString();
                        txtNIT.Text = registro["nit_cliente"].ToString();
                        txtDireccion.Text = registro["direccion_cliente"].ToString();
                    }

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                MessageBox.Show("Error al cargar la Base de Datos", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

       

        private void dgvFactura_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {

            //Calculo de bon/desc, subtotal, subtotal/desc,
            //No muestra precio pero si se toma de la tabla para el respectivo calculo

            double dBono = 5.25;
            double dDesc = 0;
            double dPivote = 0;
            try
            {
                if (dgvFactura.Rows[e.RowIndex].Cells["cbxProducto"].Value != null)
                {
                    if (dgvFactura.Rows[e.RowIndex].Cells["txtCantidad"].Value != null)
                    {
                        IDProducto = int.Parse(dgvFactura.Rows[e.RowIndex].Cells["cbxProducto"].Value.ToString());
                        string sSQL = "SELECT precio_producto FROM producto WHERE pk_id_producto=" + IDProducto;
                        OdbcCommand comando = new OdbcCommand(sSQL, cn.conexion());
                        OdbcDataReader registro = comando.ExecuteReader();

                        Cantidad = int.Parse(dgvFactura.Rows[e.RowIndex].Cells["txtCantidad"].Value.ToString());

                        while (registro.Read())
                        {
                            Precio = double.Parse(registro["precio_producto"].ToString());
                        }
                        
                        if (dgvFactura.Rows[e.RowIndex].Cells["txtDescuento"].Value != null)
                        {
                            dDesc = double.Parse(dgvFactura.Rows[e.RowIndex].Cells["txtDescuento"].Value.ToString());
                            if (dgvFactura.Rows[e.RowIndex].Cells["txtDescuento"].Value.ToString() == "0")
                            {
                                SubTotal = Precio * Cantidad;
                                dgvFactura.Rows[e.RowIndex].Cells["txtSubtotal"].Value = SubTotal;
                                dgvFactura.Rows[e.RowIndex].Cells["txtSubtotalDescuento"].Value = SubTotal;
                            }
                            else
                            {
                                dPivote = (Precio * Cantidad) * dDesc;
                                SubTotal = (Precio * Cantidad) - dPivote;
                                dgvFactura.Rows[e.RowIndex].Cells["txtSubtotal"].Value = (Precio * Cantidad);
                                dgvFactura.Rows[e.RowIndex].Cells["txtSubtotalDescuento"].Value = SubTotal;
                            }
                        }

                    }

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                MessageBox.Show("Error al cargar factura detalle", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            if (RegistrarFactura() == true)
            {
                LimpiarComponentes();
            }
        }

        //Limpia componetes incluyendo grid
        private void LimpiarComponentes()
        {
            cbxCliente.SelectedIndex = -1;
            txtNoFactura.Text = "";
            dtpFecha.Value = DateTime.Now;

            foreach (DataGridViewRow row in dgvFactura.Rows)
            {
                row.Cells["cbxProducto"].Value = null;
                row.Cells["txtCantidad"].Value = null;
                row.Cells["txtDescuento"].Value = null;
                row.Cells["txtSubtotal"].Value = null;
                row.Cells["txtSubtotalDescuento"].Value = null;
            }
            dgvFactura.Rows.Clear();
            txtTotal.Text = "0";
            BloquearComponentes();
        }

        private void cbxEmpleado_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        //llena datos para Factura Encabezado
        private clsFactura llenarCamposFacturaEncabezado(double Total)
        {

            DateTime dtFecha = dtpFecha.Value;
            clsFactura auxMantenimiento = new clsFactura();
            auxMantenimiento.IdFactura = int.Parse(txtNoFactura.Text);
            auxMantenimiento.IdEmpleado = int.Parse(cbxEmpleado.SelectedItem.ToString());
            auxMantenimiento.IdCliente = int.Parse(cbxCliente.SelectedItem.ToString());
            auxMantenimiento.IdTipoVenta = int.Parse(cbxTipoVenta.SelectedItem.ToString());
            auxMantenimiento.FechaFactura1 = dtFecha;
            auxMantenimiento.TotalVenta = Total;
            return auxMantenimiento;
        }

        //Llena datos para Factura Detalle
        private clsFacturaDetalle llenarCamposFacturaDetalle(int CodLinea, int Producto, int Cantidad, double DescuentoU, double SubTotal, double SubDesc)
        {
            clsFacturaDetalle auxMantenimiento = new clsFacturaDetalle();
            auxMantenimiento.IdFactura = int.Parse(txtNoFactura.Text);
            auxMantenimiento.CodLinea = CodLinea;
            auxMantenimiento.IdProducto = Producto;
            auxMantenimiento.Cantidad1 = Cantidad;
            auxMantenimiento.Descuento = DescuentoU;
            auxMantenimiento.SubTotal = SubTotal;
            auxMantenimiento.SubTotalDescuento = SubDesc;
            return auxMantenimiento;
        }

        //Sumar Total 
        private double SumarColumnas()
        {
            TotalValor = 0;
            try
            {
                foreach (DataGridViewRow row in dgvFactura.Rows)
                {
                    if (row.Cells["txtSubtotalDescuento"].Value != null)
                        TotalValor += (double)row.Cells["txtSubtotalDescuento"].Value;
                }
                txtTotal.Text = TotalValor.ToString();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                MessageBox.Show("Error total Factura", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return TotalValor;
        }

        //Registrar Factura
        private bool RegistrarFactura()
        {
            int CodLinea = 0, Producto, Cantidad;
            double DescuentoU, SubtotalU, SubDesc;
            try
            {
                this.facturaEncabezado = llenarCamposFacturaEncabezado(SumarColumnas());
                controladorFactura.InsertarFactura(facturaEncabezado);
                int iFilas = dgvFactura.Rows.Count;
                Console.WriteLine(iFilas);
                //Linea por linea del grid inserta a detalle compra
                while (CodLinea < (iFilas - 1))
                {
                    Producto = int.Parse(dgvFactura.Rows[CodLinea].Cells["cbxProducto"].Value.ToString());
                    Cantidad = int.Parse(dgvFactura.Rows[CodLinea].Cells["txtCantidad"].Value.ToString());
                    DescuentoU = double.Parse(dgvFactura.Rows[CodLinea].Cells["txtDescuento"].Value.ToString());
                    SubtotalU = double.Parse(dgvFactura.Rows[CodLinea].Cells["txtSubtotal"].Value.ToString());
                    SubDesc = double.Parse(dgvFactura.Rows[CodLinea].Cells["txtSubtotalDescuento"].Value.ToString());
                    //string sSQL = "SELECT producto FROM producto_scm AND pk_id_producto=" + Producto + ";";
                    ++CodLinea;
                    this.facturaDetalle = llenarCamposFacturaDetalle(CodLinea, Producto, Cantidad, DescuentoU, SubtotalU, SubDesc);
                    controladorFactura.InsertarDetalleFactura(facturaDetalle);

                }
                //  transaccion.Commit();
                MessageBox.Show("Datos de Factura Ingresados", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Console.WriteLine("Factura Exitosa");
                return true;

            }
            catch (Exception ex)
            {
                // transaccion.Rollback();
                Console.WriteLine(ex.Message);
                Console.WriteLine("Factura Fallida");
                MessageBox.Show("Error al Guardar Datos de Factura", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
                throw;
            }
        }

    }
}
