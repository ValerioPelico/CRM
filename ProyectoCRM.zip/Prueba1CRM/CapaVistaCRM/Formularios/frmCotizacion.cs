﻿using CapaControladorCRM;
using CapaControladorCRM.ControlProcesos;
using CapaModeloCRM;
using CapaModeloCRM.Procesos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Odbc;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaVistaCRM.Formularios
{
    public partial class frmCotizacion : Form
    {
        clsConexion cn = new clsConexion();
        //Variables Globales
        private clsControladorCotizacion controladorCotizacion = new clsControladorCotizacion();
        private clsCotizacion cotizacionEncabezado;
        private clsCotizacionDetalle cotizacionDetalle;
        private clsConexion conexion = new clsConexion();
        private int IDProducto, Cantidad;
        private double Precio, SubTotal, descuento, subtotaldesc, TotalValor;

        public frmCotizacion()
        {
            InitializeComponent();
            BloquearComponentes();
            cargarClientes();
            cargarProductos();
            tltCliente.SetToolTip(this.cbxCliente, "Ingrese el Código del Empleado");
        }

        //Bloquea componentes
        private void BloquearComponentes()
        {
            //dgvCotizacion.Enabled = false;
            dtpFecha.Enabled = false;
            txtApellidos.Enabled = false;
            txtDireccion.Enabled = false;
            txtNIT.Enabled = false;
            //txtNoCotizacion.Enabled = false;
            txtNombreCliente.Enabled = false;
            txtTotal.Enabled = false;
        }

        //Carga datos a combobx clientes
        private void cargarClientes()
        {
            try
            {
                string sSQL = "SELECT pk_id_cliente FROM clientes";
                OdbcCommand comando = new OdbcCommand(sSQL, cn.conexion());
                OdbcDataReader registro = comando.ExecuteReader();

                cbxCliente.DropDownStyle = ComboBoxStyle.DropDownList;
                while (registro.Read())
                {
                    cbxCliente.Items.Add(registro["pk_id_cliente"].ToString());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                MessageBox.Show("Error al cargar datos combobox", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void cbxCliente_SelectedIndexChanged(object sender, EventArgs e)
        {
            //Toma datos y los muestra en textbox, de acuerdo al id seleccionado
            try
            {

                if (cbxCliente.SelectedIndex >= 0)
                {
                    string sSQL = "SELECT nombre_cliente, apellido_cliente, nit_cliente, direccion_cliente FROM clientes WHERE pk_id_cliente=" + int.Parse(cbxCliente.SelectedItem.ToString());
                    OdbcCommand comando = new OdbcCommand(sSQL, cn.conexion());
                    OdbcDataReader registro = comando.ExecuteReader();

                    while (registro.Read())
                    {
                        txtNombreCliente.Text = registro["nombre_cliente"].ToString();
                        txtApellidos.Text = registro["apellido_cliente"].ToString();
                        txtNIT.Text = registro["nit_cliente"].ToString();
                        txtDireccion.Text = registro["direccion_cliente"].ToString();
                    }

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                MessageBox.Show("Error al cargar la Base de Datos", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private void cargarProductos()
        {
            cbxProducto.ValueMember = "pk_id_producto";
            cbxProducto.DisplayMember = "nombre_producto";
            cbxProducto.DataSource = controladorCotizacion.obtenerDatos("pk_id_producto", "nombre_producto", "producto");
        }

        //Guardar datos
        private void btnRegistrar_Click(object sender, EventArgs e)
        {
                if (RegistrarCotizacion() == true)
                {
                    LimpiarComponentes();
                }
            
        }

        //Limpia componetes incluyendo grid
        private void LimpiarComponentes()
        {
            cbxCliente.SelectedIndex = -1;
            txtNoCotizacion.Text = "";
            dtpFecha.Value = DateTime.Now;
            
            foreach (DataGridViewRow row in dgvCotizacion.Rows)
            {
                row.Cells["cbxProducto"].Value = null;
                row.Cells["txtCantidad"].Value = null;
                row.Cells["txtDescuento"].Value = null;
                row.Cells["txtSubtotal"].Value = null;
                row.Cells["txtSubtotalDescuento"].Value = null;
            }
            dgvCotizacion.Rows.Clear();
            txtTotal.Text = "0";
            BloquearComponentes();
        }

        private void frmCotizacion_Load(object sender, EventArgs e)
        {
           // this.Size = new Size(400, 600);
        }

        private void dgvCotizacion_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            //Calculo de bon/desc, subtotal, subtotal/desc,
            //No muestra precio pero si se toma de la tabla para el respectivo calculo


            double dBono = 5.25;
            double dDesc = 0.10;
            double dPivote = 0;
            try
            {
                if (dgvCotizacion.Rows[e.RowIndex].Cells["cbxProducto"].Value != null)
                {
                    if (dgvCotizacion.Rows[e.RowIndex].Cells["txtCantidad"].Value != null)
                    {
                        IDProducto = int.Parse(dgvCotizacion.Rows[e.RowIndex].Cells["cbxProducto"].Value.ToString());
                        string sSQL = "SELECT precio_producto FROM producto WHERE pk_id_producto=" + IDProducto;
                        OdbcCommand comando = new OdbcCommand(sSQL, cn.conexion());
                        OdbcDataReader registro = comando.ExecuteReader();

                        Cantidad = int.Parse(dgvCotizacion.Rows[e.RowIndex].Cells["txtCantidad"].Value.ToString());

                        while (registro.Read())
                        {
                            dgvCotizacion.Rows[e.RowIndex].Cells["txtPrecio"].Value = registro["precio_producto"];
                        }
                        Precio = double.Parse(dgvCotizacion.Rows[e.RowIndex].Cells["txtPrecio"].Value.ToString());
                        if (dgvCotizacion.Rows[e.RowIndex].Cells["txtDescuento"].Value != null)
                        {
                            if (dgvCotizacion.Rows[e.RowIndex].Cells["txtDescuento"].Value.ToString() == "0")
                            {
                                SubTotal = Precio * Cantidad;
                                dgvCotizacion.Rows[e.RowIndex].Cells["txtSubtotal"].Value = SubTotal;
                                dgvCotizacion.Rows[e.RowIndex].Cells["txtSubtotalDescuento"].Value = SubTotal;
                            }
                            else
                            {
                                dPivote = (Precio * Cantidad) * dDesc;
                                SubTotal = (Precio * Cantidad) - dPivote;
                                dgvCotizacion.Rows[e.RowIndex].Cells["txtSubtotal"].Value = (Precio*Cantidad);
                                dgvCotizacion.Rows[e.RowIndex].Cells["txtSubtotalDescuento"].Value = SubTotal;
                            }
                        }
                     

                    }

                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                MessageBox.Show("Error al cargar factura detalle", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        //Llena datos para Cotizacion Encabezado
        private clsCotizacion llenarCamposCotizacionEncabezado(double Total)
        {

            DateTime dtFecha = dtpFecha.Value;
            clsCotizacion auxMantenimiento = new clsCotizacion();
            auxMantenimiento.IdCotizacion = int.Parse(txtNoCotizacion.Text);
            auxMantenimiento.IdCliente = int.Parse(cbxCliente.SelectedItem.ToString());
            auxMantenimiento.FechaCotizacion1 = dtFecha;
            auxMantenimiento.TotalCotizacion = Total;
            return auxMantenimiento;
        }

        //Llena datos para Cotizacion Detalle
        private clsCotizacionDetalle llenarCamposCotizacionDetalle(int CodLinea, int Producto, int Cantidad, double PrecioP, double SubTotal, double DescuentoU, double SubDesc)
        {
            clsCotizacionDetalle auxMantenimiento = new clsCotizacionDetalle();
            auxMantenimiento.IdCotizacion = int.Parse(txtNoCotizacion.Text);
            auxMantenimiento.CodLinea = CodLinea;
            auxMantenimiento.IdProducto = Producto;
            auxMantenimiento.Cantidad1 = Cantidad;
            auxMantenimiento.PrecioProducto = PrecioP;
            auxMantenimiento.SubTotal = SubTotal;
            auxMantenimiento.Descuento = DescuentoU;
            auxMantenimiento.SubTotalDescuento = SubDesc;
            return auxMantenimiento;
        }

        //Sumar Total 
        private double SumarColumnas()
        {
            TotalValor = 0;
            try
            {
                foreach (DataGridViewRow row in dgvCotizacion.Rows)
                {
                    if (row.Cells["txtSubtotalDescuento"].Value != null)
                        TotalValor += (double)row.Cells["txtSubtotalDescuento"].Value;
                }
                txtTotal.Text = TotalValor.ToString();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                MessageBox.Show("Error en total de la Cotizacion", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            return TotalValor;
        }

        //Registrar Cotizacion
        private bool RegistrarCotizacion()
        {
            int CodLinea = 0, Producto, Cantidad;
            double Precio, DescuentoU, SubtotalU, SubDesc;
            try
            {
                this.cotizacionEncabezado = llenarCamposCotizacionEncabezado(SumarColumnas());
                controladorCotizacion.InsertarCotizacion(cotizacionEncabezado);
                int iFilas = dgvCotizacion.Rows.Count;
                Console.WriteLine(iFilas);
                //Linea por linea del grid inserta a detalle compra
                while (CodLinea < (iFilas - 1))
                {
                    Producto = int.Parse(dgvCotizacion.Rows[CodLinea].Cells["cbxProducto"].Value.ToString());
                    Cantidad = int.Parse(dgvCotizacion.Rows[CodLinea].Cells["txtCantidad"].Value.ToString());
                    Precio = double.Parse(dgvCotizacion.Rows[CodLinea].Cells["txtPrecio"].Value.ToString());
                    DescuentoU = double.Parse(dgvCotizacion.Rows[CodLinea].Cells["txtDescuento"].Value.ToString());
                    SubtotalU = double.Parse(dgvCotizacion.Rows[CodLinea].Cells["txtSubtotal"].Value.ToString());
                    SubDesc = double.Parse(dgvCotizacion.Rows[CodLinea].Cells["txtSubtotalDescuento"].Value.ToString());
                    ++CodLinea;
                    this.cotizacionDetalle = llenarCamposCotizacionDetalle(CodLinea, Producto, Cantidad, Precio, DescuentoU, SubtotalU, SubDesc);
                    controladorCotizacion.InsertarDetalleCotizacion(cotizacionDetalle);

                }
                //  transaccion.Commit();
                MessageBox.Show("Datos de Cotizacion Ingresados", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Console.WriteLine("Cotizacion Exitosa");
                return true;

            }
            catch (Exception ex)
            {
                // transaccion.Rollback();
                Console.WriteLine(ex.Message);
                Console.WriteLine("Compra Fallida");
                MessageBox.Show("Error al Guardar Datos de Cotizacion", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
                throw;
            }
        }

    }
}
