﻿namespace CapaVistaCRM.Formularios
{
    partial class frmFactura
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtNoFactura = new System.Windows.Forms.TextBox();
            this.lblFactura = new System.Windows.Forms.Label();
            this.gboxDatosFactura = new System.Windows.Forms.GroupBox();
            this.dtpFecha = new System.Windows.Forms.DateTimePicker();
            this.cbxTipoVenta = new System.Windows.Forms.ComboBox();
            this.lblTipoPago = new System.Windows.Forms.Label();
            this.lblFecha = new System.Windows.Forms.Label();
            this.cbxEmpleado = new System.Windows.Forms.ComboBox();
            this.lblIDEmpleado = new System.Windows.Forms.Label();
            this.gboxDatosCliente = new System.Windows.Forms.GroupBox();
            this.txtDireccion = new System.Windows.Forms.TextBox();
            this.lblDireccion = new System.Windows.Forms.Label();
            this.txtNIT = new System.Windows.Forms.TextBox();
            this.lblNIT = new System.Windows.Forms.Label();
            this.txtApellidos = new System.Windows.Forms.TextBox();
            this.lblApellidos = new System.Windows.Forms.Label();
            this.txtNombreCliente = new System.Windows.Forms.TextBox();
            this.lblIDCliente = new System.Windows.Forms.Label();
            this.lblNombre = new System.Windows.Forms.Label();
            this.cbxCliente = new System.Windows.Forms.ComboBox();
            this.btnRegistrar = new System.Windows.Forms.Button();
            this.txtTotal = new System.Windows.Forms.TextBox();
            this.lblTotal = new System.Windows.Forms.Label();
            this.dgvFactura = new System.Windows.Forms.DataGridView();
            this.cbxProducto = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.txtCantidad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtDescuento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtSubtotal = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.txtSubtotalDescuento = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tltCliente = new System.Windows.Forms.ToolTip(this.components);
            this.tltEmpleado = new System.Windows.Forms.ToolTip(this.components);
            this.tltTipoVenta = new System.Windows.Forms.ToolTip(this.components);
            this.gboxDatosFactura.SuspendLayout();
            this.gboxDatosCliente.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFactura)).BeginInit();
            this.SuspendLayout();
            // 
            // txtNoFactura
            // 
            this.txtNoFactura.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtNoFactura.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNoFactura.Location = new System.Drawing.Point(178, 12);
            this.txtNoFactura.Name = "txtNoFactura";
            this.txtNoFactura.Size = new System.Drawing.Size(169, 30);
            this.txtNoFactura.TabIndex = 24;
            // 
            // lblFactura
            // 
            this.lblFactura.AutoSize = true;
            this.lblFactura.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFactura.Location = new System.Drawing.Point(45, 14);
            this.lblFactura.Name = "lblFactura";
            this.lblFactura.Size = new System.Drawing.Size(103, 22);
            this.lblFactura.TabIndex = 23;
            this.lblFactura.Text = "No. Factura";
            // 
            // gboxDatosFactura
            // 
            this.gboxDatosFactura.BackColor = System.Drawing.Color.White;
            this.gboxDatosFactura.Controls.Add(this.dtpFecha);
            this.gboxDatosFactura.Controls.Add(this.cbxTipoVenta);
            this.gboxDatosFactura.Controls.Add(this.lblTipoPago);
            this.gboxDatosFactura.Controls.Add(this.lblFecha);
            this.gboxDatosFactura.Controls.Add(this.cbxEmpleado);
            this.gboxDatosFactura.Controls.Add(this.lblIDEmpleado);
            this.gboxDatosFactura.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gboxDatosFactura.Location = new System.Drawing.Point(35, 226);
            this.gboxDatosFactura.Name = "gboxDatosFactura";
            this.gboxDatosFactura.Size = new System.Drawing.Size(915, 166);
            this.gboxDatosFactura.TabIndex = 22;
            this.gboxDatosFactura.TabStop = false;
            this.gboxDatosFactura.Text = "Datos Factura";
            // 
            // dtpFecha
            // 
            this.dtpFecha.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpFecha.Location = new System.Drawing.Point(529, 39);
            this.dtpFecha.Name = "dtpFecha";
            this.dtpFecha.Size = new System.Drawing.Size(293, 30);
            this.dtpFecha.TabIndex = 12;
            // 
            // cbxTipoVenta
            // 
            this.cbxTipoVenta.BackColor = System.Drawing.Color.WhiteSmoke;
            this.cbxTipoVenta.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxTipoVenta.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxTipoVenta.FormattingEnabled = true;
            this.cbxTipoVenta.Location = new System.Drawing.Point(232, 97);
            this.cbxTipoVenta.Name = "cbxTipoVenta";
            this.cbxTipoVenta.Size = new System.Drawing.Size(169, 30);
            this.cbxTipoVenta.TabIndex = 9;
            // 
            // lblTipoPago
            // 
            this.lblTipoPago.AutoSize = true;
            this.lblTipoPago.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTipoPago.Location = new System.Drawing.Point(38, 105);
            this.lblTipoPago.Name = "lblTipoPago";
            this.lblTipoPago.Size = new System.Drawing.Size(124, 22);
            this.lblTipoPago.TabIndex = 8;
            this.lblTipoPago.Text = "Tipo de venta:";
            // 
            // lblFecha
            // 
            this.lblFecha.AutoSize = true;
            this.lblFecha.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFecha.Location = new System.Drawing.Point(446, 39);
            this.lblFecha.Name = "lblFecha";
            this.lblFecha.Size = new System.Drawing.Size(57, 22);
            this.lblFecha.TabIndex = 6;
            this.lblFecha.Text = "Fecha";
            // 
            // cbxEmpleado
            // 
            this.cbxEmpleado.BackColor = System.Drawing.Color.WhiteSmoke;
            this.cbxEmpleado.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxEmpleado.FormattingEnabled = true;
            this.cbxEmpleado.Location = new System.Drawing.Point(232, 31);
            this.cbxEmpleado.Name = "cbxEmpleado";
            this.cbxEmpleado.Size = new System.Drawing.Size(169, 30);
            this.cbxEmpleado.TabIndex = 5;
            this.cbxEmpleado.SelectedIndexChanged += new System.EventHandler(this.cbxEmpleado_SelectedIndexChanged);
            // 
            // lblIDEmpleado
            // 
            this.lblIDEmpleado.AutoSize = true;
            this.lblIDEmpleado.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIDEmpleado.Location = new System.Drawing.Point(38, 39);
            this.lblIDEmpleado.Name = "lblIDEmpleado";
            this.lblIDEmpleado.Size = new System.Drawing.Size(115, 22);
            this.lblIDEmpleado.TabIndex = 4;
            this.lblIDEmpleado.Text = "ID Empleado";
            // 
            // gboxDatosCliente
            // 
            this.gboxDatosCliente.BackColor = System.Drawing.Color.White;
            this.gboxDatosCliente.Controls.Add(this.txtDireccion);
            this.gboxDatosCliente.Controls.Add(this.lblDireccion);
            this.gboxDatosCliente.Controls.Add(this.txtNIT);
            this.gboxDatosCliente.Controls.Add(this.lblNIT);
            this.gboxDatosCliente.Controls.Add(this.txtApellidos);
            this.gboxDatosCliente.Controls.Add(this.lblApellidos);
            this.gboxDatosCliente.Controls.Add(this.txtNombreCliente);
            this.gboxDatosCliente.Controls.Add(this.lblIDCliente);
            this.gboxDatosCliente.Controls.Add(this.lblNombre);
            this.gboxDatosCliente.Controls.Add(this.cbxCliente);
            this.gboxDatosCliente.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gboxDatosCliente.Location = new System.Drawing.Point(35, 48);
            this.gboxDatosCliente.Name = "gboxDatosCliente";
            this.gboxDatosCliente.Size = new System.Drawing.Size(915, 163);
            this.gboxDatosCliente.TabIndex = 21;
            this.gboxDatosCliente.TabStop = false;
            this.gboxDatosCliente.Text = "Datos de Cliente";
            // 
            // txtDireccion
            // 
            this.txtDireccion.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtDireccion.Enabled = false;
            this.txtDireccion.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDireccion.Location = new System.Drawing.Point(441, 93);
            this.txtDireccion.Name = "txtDireccion";
            this.txtDireccion.Size = new System.Drawing.Size(393, 30);
            this.txtDireccion.TabIndex = 15;
            // 
            // lblDireccion
            // 
            this.lblDireccion.AutoSize = true;
            this.lblDireccion.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDireccion.Location = new System.Drawing.Point(308, 101);
            this.lblDireccion.Name = "lblDireccion";
            this.lblDireccion.Size = new System.Drawing.Size(89, 22);
            this.lblDireccion.TabIndex = 14;
            this.lblDireccion.Text = "Direccion";
            // 
            // txtNIT
            // 
            this.txtNIT.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtNIT.Enabled = false;
            this.txtNIT.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNIT.Location = new System.Drawing.Point(89, 98);
            this.txtNIT.Name = "txtNIT";
            this.txtNIT.Size = new System.Drawing.Size(169, 30);
            this.txtNIT.TabIndex = 13;
            // 
            // lblNIT
            // 
            this.lblNIT.AutoSize = true;
            this.lblNIT.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNIT.Location = new System.Drawing.Point(30, 106);
            this.lblNIT.Name = "lblNIT";
            this.lblNIT.Size = new System.Drawing.Size(42, 22);
            this.lblNIT.TabIndex = 12;
            this.lblNIT.Text = "NIT";
            // 
            // txtApellidos
            // 
            this.txtApellidos.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtApellidos.Enabled = false;
            this.txtApellidos.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtApellidos.Location = new System.Drawing.Point(704, 36);
            this.txtApellidos.Name = "txtApellidos";
            this.txtApellidos.Size = new System.Drawing.Size(169, 30);
            this.txtApellidos.TabIndex = 11;
            // 
            // lblApellidos
            // 
            this.lblApellidos.AutoSize = true;
            this.lblApellidos.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApellidos.Location = new System.Drawing.Point(595, 41);
            this.lblApellidos.Name = "lblApellidos";
            this.lblApellidos.Size = new System.Drawing.Size(89, 22);
            this.lblApellidos.TabIndex = 10;
            this.lblApellidos.Text = "Apellidos";
            // 
            // txtNombreCliente
            // 
            this.txtNombreCliente.BackColor = System.Drawing.Color.WhiteSmoke;
            this.txtNombreCliente.Enabled = false;
            this.txtNombreCliente.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNombreCliente.Location = new System.Drawing.Point(388, 33);
            this.txtNombreCliente.Name = "txtNombreCliente";
            this.txtNombreCliente.Size = new System.Drawing.Size(169, 30);
            this.txtNombreCliente.TabIndex = 9;
            // 
            // lblIDCliente
            // 
            this.lblIDCliente.AutoSize = true;
            this.lblIDCliente.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblIDCliente.Location = new System.Drawing.Point(23, 36);
            this.lblIDCliente.Name = "lblIDCliente";
            this.lblIDCliente.Size = new System.Drawing.Size(92, 22);
            this.lblIDCliente.TabIndex = 6;
            this.lblIDCliente.Text = "ID Cliente";
            // 
            // lblNombre
            // 
            this.lblNombre.AutoSize = true;
            this.lblNombre.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNombre.Location = new System.Drawing.Point(308, 36);
            this.lblNombre.Name = "lblNombre";
            this.lblNombre.Size = new System.Drawing.Size(74, 22);
            this.lblNombre.TabIndex = 8;
            this.lblNombre.Text = "Nombre";
            // 
            // cbxCliente
            // 
            this.cbxCliente.BackColor = System.Drawing.Color.WhiteSmoke;
            this.cbxCliente.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxCliente.FormattingEnabled = true;
            this.cbxCliente.Location = new System.Drawing.Point(143, 36);
            this.cbxCliente.Name = "cbxCliente";
            this.cbxCliente.Size = new System.Drawing.Size(133, 30);
            this.cbxCliente.TabIndex = 7;
            this.cbxCliente.SelectedIndexChanged += new System.EventHandler(this.cbxCliente_SelectedIndexChanged);
            // 
            // btnRegistrar
            // 
            this.btnRegistrar.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRegistrar.Location = new System.Drawing.Point(731, 724);
            this.btnRegistrar.Name = "btnRegistrar";
            this.btnRegistrar.Size = new System.Drawing.Size(219, 41);
            this.btnRegistrar.TabIndex = 30;
            this.btnRegistrar.Text = "Registrar Factura";
            this.btnRegistrar.UseVisualStyleBackColor = true;
            this.btnRegistrar.Click += new System.EventHandler(this.btnRegistrar_Click);
            // 
            // txtTotal
            // 
            this.txtTotal.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotal.Location = new System.Drawing.Point(160, 724);
            this.txtTotal.Name = "txtTotal";
            this.txtTotal.Size = new System.Drawing.Size(122, 30);
            this.txtTotal.TabIndex = 29;
            // 
            // lblTotal
            // 
            this.lblTotal.AutoSize = true;
            this.lblTotal.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotal.Location = new System.Drawing.Point(56, 727);
            this.lblTotal.Name = "lblTotal";
            this.lblTotal.Size = new System.Drawing.Size(57, 22);
            this.lblTotal.TabIndex = 28;
            this.lblTotal.Text = "Total:";
            // 
            // dgvFactura
            // 
            this.dgvFactura.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvFactura.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvFactura.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cbxProducto,
            this.txtCantidad,
            this.txtDescuento,
            this.txtSubtotal,
            this.txtSubtotalDescuento});
            this.dgvFactura.Location = new System.Drawing.Point(35, 415);
            this.dgvFactura.Name = "dgvFactura";
            this.dgvFactura.RowHeadersWidth = 51;
            this.dgvFactura.RowTemplate.Height = 24;
            this.dgvFactura.Size = new System.Drawing.Size(915, 294);
            this.dgvFactura.TabIndex = 27;
            this.dgvFactura.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvFactura_CellEndEdit);
            // 
            // cbxProducto
            // 
            this.cbxProducto.FillWeight = 67.13211F;
            this.cbxProducto.HeaderText = "Producto";
            this.cbxProducto.MinimumWidth = 6;
            this.cbxProducto.Name = "cbxProducto";
            // 
            // txtCantidad
            // 
            this.txtCantidad.FillWeight = 85.92435F;
            this.txtCantidad.HeaderText = "Cantidad";
            this.txtCantidad.MinimumWidth = 6;
            this.txtCantidad.Name = "txtCantidad";
            // 
            // txtDescuento
            // 
            this.txtDescuento.FillWeight = 102.1935F;
            this.txtDescuento.HeaderText = "Descuento";
            this.txtDescuento.MinimumWidth = 6;
            this.txtDescuento.Name = "txtDescuento";
            // 
            // txtSubtotal
            // 
            this.txtSubtotal.FillWeight = 116.2782F;
            this.txtSubtotal.HeaderText = "SubTotal";
            this.txtSubtotal.MinimumWidth = 6;
            this.txtSubtotal.Name = "txtSubtotal";
            // 
            // txtSubtotalDescuento
            // 
            this.txtSubtotalDescuento.FillWeight = 128.4719F;
            this.txtSubtotalDescuento.HeaderText = "Subtotal Descuento";
            this.txtSubtotalDescuento.MinimumWidth = 6;
            this.txtSubtotalDescuento.Name = "txtSubtotalDescuento";
            // 
            // tltCliente
            // 
            this.tltCliente.AutoPopDelay = 5000;
            this.tltCliente.InitialDelay = 200;
            this.tltCliente.IsBalloon = true;
            this.tltCliente.ReshowDelay = 100;
            this.tltCliente.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.tltCliente.ToolTipTitle = "Ingrese Codigo Cliente";
            // 
            // tltEmpleado
            // 
            this.tltEmpleado.AutoPopDelay = 5000;
            this.tltEmpleado.InitialDelay = 200;
            this.tltEmpleado.IsBalloon = true;
            this.tltEmpleado.ReshowDelay = 100;
            this.tltEmpleado.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.tltEmpleado.ToolTipTitle = "Ingrese el Codigo del Empleado";
            // 
            // tltTipoVenta
            // 
            this.tltTipoVenta.AutoPopDelay = 5000;
            this.tltTipoVenta.InitialDelay = 200;
            this.tltTipoVenta.IsBalloon = true;
            this.tltTipoVenta.ReshowDelay = 100;
            this.tltTipoVenta.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.tltTipoVenta.ToolTipTitle = "Ingrese el Tipo de Venta";
            // 
            // frmFactura
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.ClientSize = new System.Drawing.Size(993, 795);
            this.Controls.Add(this.btnRegistrar);
            this.Controls.Add(this.txtTotal);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.dgvFactura);
            this.Controls.Add(this.txtNoFactura);
            this.Controls.Add(this.lblFactura);
            this.Controls.Add(this.gboxDatosFactura);
            this.Controls.Add(this.gboxDatosCliente);
            this.Name = "frmFactura";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "4701 - Factura";
            this.gboxDatosFactura.ResumeLayout(false);
            this.gboxDatosFactura.PerformLayout();
            this.gboxDatosCliente.ResumeLayout(false);
            this.gboxDatosCliente.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvFactura)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNoFactura;
        private System.Windows.Forms.Label lblFactura;
        private System.Windows.Forms.GroupBox gboxDatosFactura;
        private System.Windows.Forms.DateTimePicker dtpFecha;
        private System.Windows.Forms.ComboBox cbxTipoVenta;
        private System.Windows.Forms.Label lblTipoPago;
        private System.Windows.Forms.Label lblFecha;
        private System.Windows.Forms.ComboBox cbxEmpleado;
        private System.Windows.Forms.Label lblIDEmpleado;
        private System.Windows.Forms.GroupBox gboxDatosCliente;
        private System.Windows.Forms.TextBox txtDireccion;
        private System.Windows.Forms.Label lblDireccion;
        private System.Windows.Forms.TextBox txtNIT;
        private System.Windows.Forms.Label lblNIT;
        private System.Windows.Forms.TextBox txtApellidos;
        private System.Windows.Forms.Label lblApellidos;
        private System.Windows.Forms.TextBox txtNombreCliente;
        private System.Windows.Forms.Label lblIDCliente;
        private System.Windows.Forms.Label lblNombre;
        private System.Windows.Forms.ComboBox cbxCliente;
        private System.Windows.Forms.Button btnRegistrar;
        private System.Windows.Forms.TextBox txtTotal;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.DataGridView dgvFactura;
        private System.Windows.Forms.DataGridViewComboBoxColumn cbxProducto;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtCantidad;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtDescuento;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtSubtotal;
        private System.Windows.Forms.DataGridViewTextBoxColumn txtSubtotalDescuento;
        private System.Windows.Forms.ToolTip tltCliente;
        private System.Windows.Forms.ToolTip tltEmpleado;
        private System.Windows.Forms.ToolTip tltTipoVenta;
    }
}