﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaModeloSeguridad
{
    public class clsVariableUsuario
    {

        static int usuario;

        public int VariableUsu
        {
            get { return usuario; }
            set { usuario = value; }
        }

    }
}
