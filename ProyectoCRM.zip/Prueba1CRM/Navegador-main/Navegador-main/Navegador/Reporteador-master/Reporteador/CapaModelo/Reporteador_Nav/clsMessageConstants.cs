﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaModeloReporteador.Reporteador_Nav
{
    public class clsMessageConstants
    {
       public const string SUCCESS = "El texto ha sido hallado existosamente";
       public const string FAILURE = "El texto NO ha sido hallado";
    }
}
